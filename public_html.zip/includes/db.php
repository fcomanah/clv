<?php
  $HOST_MYSQL="localhost";
	$USUARIO_MYSQL="clvu";
	$SENHA_MYSQL="clvp";
	$BASEdeDADOS_MYSQL="clv";

	$link=mysqli_connect($HOST_MYSQL,$USUARIO_MYSQL,$SENHA_MYSQL) or die("clv is not available, please try again later: 1");
	mysqli_select_db($link, $BASEdeDADOS_MYSQL) or die("clv is not available, please try again later: 2");
	mysqli_set_charset ( $link , "utf8" );
	session_start();
?>
