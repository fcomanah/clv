<?php
	include("includes/db.php");
	include("includes/auth_functions.php");
	include("includes/administrador_functions.php");

  $pedit=0;
	if($_REQUEST['command']=='login'){
    $email=$_REQUEST['email'];
    $senha=$_REQUEST['senha'];
	  list ( $_SESSION['status'], $msg, $msg_color ) = auth($link, $email, $senha);
	}else if($_REQUEST['command']=='create'){
    $administrador=array();
    $administrador[1]=$_REQUEST['aemail_c'];
    $administrador[2]=md5($_REQUEST['asenha_c']);
		$administrador[3]=$_REQUEST['anome_c'];
    $administrador[4]=$_REQUEST['asobre_c'];
    create_administrador($link,$administrador);

	}else if($_REQUEST['command']=='edit'){
    $pedit = $_REQUEST['pid'];

	}else if($_REQUEST['command']=='update'){
    $administrador=array();
    $administrador[0]=$_REQUEST['aemail_e'];
		$administrador[1]=$_REQUEST['aemail'];
    $administrador[2]=md5($_REQUEST['asenha']);
		$administrador[3]=$_REQUEST['anome'];
    $administrador[4]=$_REQUEST['asobre'];
    update_administrador($link,$administrador);

	}else if($_REQUEST['command']=='delete'){
    delete_administrador($link,$_REQUEST['aemail_e']);

	}else if($_REQUEST['command']=='logout'){
    $_SESSION['status'] = 'fora';
    $msg_color ='#0F0';
    $msg = "Logout feito com sucesso.";
  }
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Administrador</title>
<script language="javascript">
	function validate(){
		var f=document.form1;
		if(f.email.value==''){
			alert('O email é obrigatório.');
			f.email.focus();
			return false;
		}
		if(f.senha.value==''){
			alert('A senha é obrigatória.');
			f.senha.focus();
			return false;
		}
		f.command.value='login';
		f.submit();
	}
	function create(){
		var f=document.form1;
		if(f.aemail_c.value==''){
			alert('O email é obrigatório.');
			f.aemail_c.focus();
			return false;
		}
		if(f.asenha_c.value==''){
			alert('A senha é obrigatória.');
			f.asenha_c.focus();
			return false;
		}
		f.command.value='create';
		f.submit();
	}
	function edit(pid){
		document.form1.pid.value=pid;
		document.form1.command.value='edit';
		document.form1.submit();
	}
	function update(pid){
		var f=document.form1;
        f.pid.value=pid;
		if(f.aemail.value==''){
			alert('O email é obrigatório.');
			f.aemail.focus();
			return false;
		}
		if(f.asenha.value==''){
			alert('A senha é obrigatória.');
			f.asenha.focus();
			return false;
		}
		f.command.value='update';
		f.submit();
	}
	function del(pid){
		if(confirm('Você realmente quer remover esse item?')){
			document.form1.pid.value=pid;
			document.form1.command.value='delete';
			document.form1.submit();
		}
	}
</script>
</head>

<body>

<?php if($_SESSION['status'] == 'dentro'){ 	?>
        <div align="right">
            <a href="produto.php"><input type="submit" value="Produto" /></td></a>
            <a href="transacao.php"><input type="submit" value="Transação" /></td></a>
            <a href="administrador.php"><input type="submit" value="Administrador" /></td></a>
        </div>
        <form name="form2" method="POST">
            <input type="hidden" name="command" value="logout" />
            <div align="right">
                <table border="0" cellpadding="2px">
                    <tr><td>&nbsp;</td><td><input type="submit" value="Sair" /></td></tr>
                </table>
            </div>
        </form>

				<form name="form1" method="post">
				<input type="hidden" name="command" />
				<input type="hidden" name="pid" />
					<div style="margin:0px auto; width:600px;" >
				    <div style="padding-bottom:10px">
				    	<h1 align="center">Administrador</h1>
				        <div style="color:<?php echo $msg_color?>"><?php echo $msg?></div>
				    </div>
				    	<table border="0" cellpadding="5px" cellspacing="1px" style="font-family:Verdana, Geneva, sans-serif; font-size:11px; background-color:#E1E1E1" width="100%">
				    	<?php
				            	echo '<tr bgcolor="#FFFFFF" style="font-weight:bold">
				                    <td>#</td>
				                    <td>Email</td>
				                    <td>Senha</td>
				                    <td>Opções</td></tr>';

				            $administradores = read_administrador($link);

							if( count($administradores) > 0 ){
								$contador=0;
								foreach ($administradores as $administrador){
									$contador++;
									$pid   = $contador;
									$aemail =$administrador[0];
									$asenha =$administrador[1];

                  if ( $pid == $pedit ) {
							?>
				            		<tr bgcolor="#FFFFFF">
													<input type="hidden" name="aemail_e" value="<?php echo $aemail?>"/>
				                  <td><?php echo $contador?></td>
				                  <td><input type="text" name="aemail" value="<?php echo $aemail?>"/></td>
				                  <td><input type="text" name="asenha" value="<?php echo $asenha?>"/></td>
				                    <td><a href="javascript:del(<?php echo $pid?>)">Remover</a>
				                    		<a href="javascript:update(<?php echo $pid?>)">Atualizar</a></td>
				                  </tr>
				            <?php      } else { ?>
				            		<tr bgcolor="#FFFFFF">
				                        <td><?php echo $contador?></td>
				                        <td><?php echo $aemail?></td>
				                        <td><?php echo $asenha?></td>
				                        <td><a href="javascript:edit(<?php echo $pid?>)">Editar</a></td>
				                    </tr>
				            <?php      }
								}
				            }
							else{
								echo '<tr bgColor=\'#FFFFFF\'><td colspan="6" align="left">Sua Lista de Administradores está vazia!</td>';
							}
							?>
								<tr>
                    <td>+</td>
                    <td><input type="text" name="aemail_c" /></td>
                    <td><input type="text" name="asenha_c" /></td>
                    <td><a href="javascript:create()">Adicionar</a></td>
				        </tr>
							<?php
						?>
				        </table>
				    </div>
				</form>

<?php }else{?>
        <form name="form1" onsubmit="return validate()" method="POST">
            <input type="hidden" name="command" />
            <div align="center">
                <h1 align="center">Login</h1>
                <div style="color:<?php echo $msg_color; ?>"><?php echo $msg;?></div>
                <table border="0" cellpadding="2px">
                    <tr><td>Email:</td><td><input type="text" name="email" value="<?php echo $email;?>" /></td></tr>
                    <tr><td>Senha:</td><td><input type="password" name="senha" /></td></tr>
                    <tr><td>&nbsp;</td><td><input type="submit" value="Entrar" /></td></tr>
                </table>
            </div>
        </form>
<?php }?>

</body>
</html>
