<?php
// Função que valida o CPF
function validaCPF($cpf) {
    $cpf = str_pad(ereg_replace('[^0-9]', '', $cpf), 11, '0', STR_PAD_LEFT);
    if (strlen($cpf) != 11 || $cpf == '00000000000'
        || $cpf == '11111111111' || $cpf == '22222222222'
        || $cpf == '33333333333' || $cpf == '44444444444'
        || $cpf == '55555555555' || $cpf == '66666666666'
        || $cpf == '77777777777' || $cpf == '88888888888'
        || $cpf == '99999999999') {
        return false;
    } else {
        for ($t = 9; $t < 11; $t++) {
            for ($d = 0, $c = 0; $c < $t; $c++) {
                $d += $cpf{$c} * (($t + 1) - $c);
            }
            $d = ((10 * $d) % 11) % 10;
            if ($cpf{$c} != $d) {
                return false;
            }
        }
        return true;
    }
}

//Função que valida se o usuário não é um robô
function validaRobot($g_recaptcha_response) {
  //set POST variables
  $url = 'https://www.google.com/recaptcha/api/siteverify';
  $fields = array(
    'secret' =>	urlencode('6LfW-iUTAAAAANiRCt9ZElxIMDX7E_2xdImdpdbQ'),
  	'response' => urlencode($g_recaptcha_response),
  	'remoteip' => urlencode($_SERVER['REMOTE_ADDR'])
  );

  //url-ify the data for the POST
  foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
  rtrim($fields_string, '&');

  //open connection
  $ch = curl_init();

    //set the url, number of POST vars, POST data
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch,CURLOPT_URL, $url);
    curl_setopt($ch,CURLOPT_POST, count($fields));
    curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);

    //execute post
    $result = curl_exec($ch);

  //close connection
  curl_close($ch);

  return($result);
}
?>
