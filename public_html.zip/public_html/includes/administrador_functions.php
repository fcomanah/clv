<?php
	function create_administrador($link,$row){
		$result=mysqli_query($link,"INSERT INTO `administrador` (`email`, `senha`, `nome`, `sobrenome`)
		VALUES ('$row[1]', '$row[2]','$row[3]', '$row[4]');");
	}

	function read_administrador($link){
		$result=mysqli_query($link,"SELECT * FROM `administrador` ORDER BY `email`");
        $rows = array();
        while (	$row=mysqli_fetch_row($result) ){
            array_push($rows, $row);
        }
		return $rows;
	}

	function update_administrador($link,$row){
		$result=mysqli_query($link,"UPDATE `administrador` SET
			`email` = '$row[1]', `senha` = '$row[2]', `nome` = '$row[3]',
			`sobrenome` = '$row[4]' WHERE `email` = '$row[0]';");
	}

	function delete_administrador($link,$email){
		$result=mysqli_query($link,"DELETE FROM `administrador` WHERE `email`='$email'");
	}
?>
