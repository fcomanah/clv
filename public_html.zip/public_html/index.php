<?php
    if($_GET['admin']=='ZZ') {
        header("location:administrador.php");
    } else {
        header("location:catalogo.php");
    }
?>

